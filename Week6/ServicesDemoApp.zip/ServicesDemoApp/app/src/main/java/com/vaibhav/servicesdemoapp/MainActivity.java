package com.vaibhav.servicesdemoapp;

import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private ImageButton playButton;
    private ImageButton pauseButton;
    private TextView resultTextView;

    MyBoundService myBoundService;

     boolean isBoundConnection;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        playButton = findViewById(R.id.playButton);
        pauseButton=findViewById(R.id.pauseButton);
        resultTextView = findViewById(R.id.resultText);

        Intent bindServiceIntent = new Intent(this, MyBoundService.class);

        bindService(bindServiceIntent,accessToGarage,Context.BIND_AUTO_CREATE);

        pauseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(isBoundConnection){
                    myBoundService.PauseMusic();
                    resultTextView.setText(myBoundService.getAudioStatus());
                }

            }
        });

        playButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(isBoundConnection) {
                    myBoundService.PlayMusic();
                    resultTextView.setText(myBoundService.getAudioStatus());
                }
            }
        });

    }

    ServiceConnection accessToGarage = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            isBoundConnection = true;
            MyBoundService.MyBoundServiceKey keyDeliveredToActivity = (MyBoundService.MyBoundServiceKey) service;
            myBoundService = keyDeliveredToActivity.getService();
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            isBoundConnection = false;
        }
    };

    @Override
    protected void onStart() {
        super.onStart();
        IntentFilter intentFilter = new IntentFilter("MY_BROADCAST_CHANNEL");

        LocalBroadcastManager.getInstance(this).registerReceiver(myReceiver,intentFilter);
    }

    BroadcastReceiver myReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String result = intent.getStringExtra("Status");
            resultTextView.setText(result);
        }
    };


}
