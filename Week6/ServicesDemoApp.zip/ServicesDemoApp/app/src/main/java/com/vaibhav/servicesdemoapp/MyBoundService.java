package com.vaibhav.servicesdemoapp;

import android.app.Service;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Binder;
import android.os.IBinder;
import android.support.v4.content.LocalBroadcastManager;


public class MyBoundService extends Service {
    public MyBoundService() {
    }

    MediaPlayer mediaPlayer;
    Boolean isPaused;

    public String getAudioStatus() {
        return audioStatus;
    }

    public void setAudioStatus(String audioStatus) {
        this.audioStatus = audioStatus;
    }

    public void clearAudioStatus(){
        this.audioStatus = "";
    }

    private String audioStatus;
    private IBinder ibinder = new MyBoundServiceKey();

    public class MyBoundServiceKey extends Binder {

        MyBoundService getService(){
            return  MyBoundService.this;
        }
    }

    @Override
    public void onCreate() {
        super.onCreate();
        mediaPlayer = MediaPlayer.create(this, R.raw.spiderman);

        mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {

                Intent broadcastIntent = new Intent("MY_BROADCAST_CHANNEL");

                broadcastIntent.putExtra("Status","Done");

                LocalBroadcastManager.getInstance(getApplicationContext()).sendBroadcast(broadcastIntent);
                clearAudioStatus();

            }
        });

    }

    public void PlayMusic(){
        setAudioStatus("Playing");
        mediaPlayer.start();
    }

    public void PauseMusic(){

        if(mediaPlayer.isPlaying()){
            setAudioStatus("Paused");
            mediaPlayer.pause();
            isPaused = true;
        }
        else {
            mediaPlayer.pause();
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return ibinder;
    }
}
